
<script>
$(document).ready(function() {
  $('#example').DataTable();
});
</script>

<!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
<script src="public/js/style.js"></script>
<script src="../../public/js/style.js"></script>
<script src="public/owlCarousel/owl.carousel.min.js"></script>
<script src="../../public/owlCarousel/owl.carousel.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>