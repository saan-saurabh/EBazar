
    <div class="card-header">
       <a href="#" class="float-right"><button class="btn btn-primary">View All</button></a>
       <?php echo $title ?>
    </div>

