<div class="product-card card text-center myd">
 <a href="templates/views/products_page.php"><img src="public/images/products/m1.jpeg" class="card-image-center"></a>
 <a href="templates/views/products_page.php"><div class="card-body">
   <h5 class="card-title">Men's T-Shirt</h5>
   <p class="card-text">With 50% Discount</p>
   <p class="card-text text-muted text-truncate" style="margin-top: -10px;">t-shirt and more</p>
 </div></a>
</div>