<!--Product Category Section Start--> 
<section class="container-fluid">
 <div class="nav-scroller py-1 mb-2">
    <nav class="nav d-flex justify-content-between">
      <a class="p-2 text-muted" href="<?php echo $path ?>templates/views/products_page.php?product_key=man">Men <i class="fa fa-chevron-down"></i></a>
      <a class="p-2 text-muted" href="<?php echo $path ?>templates/views/products_page.php?product_key=women">Women <i class="fa fa-chevron-down"></i></a>
      <a class="p-2 text-muted" href="<?php echo $path ?>templates/views/products_page.php?product_key=kids">Kids <i class="fa fa-chevron-down"></i></a>
      <a class="p-2 text-muted" href="<?php echo $path ?>templates/views/products_page.php?product_key=mobile">Mobiles <i class="fa fa-chevron-down"></i></a>
      <a class="p-2 text-muted" href="<?php echo $path ?>templates/views/products_page.php?product_key=electronics">Electronics <i class="fa fa-chevron-down"></i></a>
      <a class="p-2 text-muted" href="<?php echo $path ?>templates/views/products_page.php?product_key=fruites">Fruits & Vegetables <i class="fa fa-chevron-down"></i></a>
      <a class="p-2 text-muted" href="<?php echo $path ?>templates/views/products_page.php?product_key=dairy">Dairy & Bakery <i class="fa fa-chevron-down"></i></a>
      <a class="p-2 text-muted" href="<?php echo $path ?>templates/views/products_page.php?product_key=grocery">Grocery <i class="fa fa-chevron-down"></i></a>
    </nav>
  </div>
  </section>
  <!--Product Category Section End--> 
