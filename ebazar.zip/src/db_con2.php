<?php

$hostname="localhost";
$user_name="id16099468_capstone";
$password="Pd@123456789";
$database="id16099468_ebazar";

?>

<?php
$con= mysqli_connect($hostname, $user_name, $password, $database) or die($mysqli_error($con));
?>